import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import AddSchool from './pages/addSchool.jsx'
import ShowSchools from './pages/showSchools.jsx'
import './index.css'

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-100">
        <nav className="bg-white shadow mb-6">
          <div className="max-w-5xl mx-auto px-4 py-4 flex gap-4">
            <Link className="font-semibold" to="/">Show Schools</Link>
            <Link className="font-semibold" to="/add">Add School</Link>
          </div>
        </nav>
        <div className="max-w-5xl mx-auto px-4">
          <Routes>
            <Route path="/" element={<ShowSchools />} />
            <Route path="/add" element={<AddSchool />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
