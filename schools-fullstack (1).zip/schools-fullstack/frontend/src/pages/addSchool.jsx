import { useState } from "react";
import axios from "axios";

export default function AddSchool() {
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    city: "",
    state: "",
    contact: "",
    email_id: "",
    image: null,
  });

  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "image") {
      setFormData({ ...formData, image: files?.[0] || null });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email_id)) {
      alert("Please enter a valid email address");
      return;
    }

    const data = new FormData();
    Object.entries(formData).forEach(([k, v]) => data.append(k, v));

    try {
      setLoading(true);
      await axios.post(import.meta.env.VITE_API_URL || "http://localhost:5000/addSchool", data, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("School Added Successfully!");
      setFormData({
        name: "",
        address: "",
        city: "",
        state: "",
        contact: "",
        email_id: "",
        image: null,
      });
      // Clear file input
      const fileInput = document.getElementById("imageInput");
      if (fileInput) fileInput.value = "";
    } catch (err) {
      console.error(err);
      alert("Error adding school");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex justify-center items-center">
      <form
        onSubmit={handleSubmit}
        className="bg-white shadow rounded-2xl p-6 w-full max-w-lg"
      >
        <h2 className="text-2xl font-bold mb-4">Add School</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input className="border p-2 rounded" placeholder="Name" name="name" value={formData.name} onChange={handleChange} required />
          <input className="border p-2 rounded" placeholder="Email" type="email" name="email_id" value={formData.email_id} onChange={handleChange} required />
          <input className="border p-2 rounded md:col-span-2" placeholder="Address" name="address" value={formData.address} onChange={handleChange} required />
          <input className="border p-2 rounded" placeholder="City" name="city" value={formData.city} onChange={handleChange} required />
          <input className="border p-2 rounded" placeholder="State" name="state" value={formData.state} onChange={handleChange} required />
          <input className="border p-2 rounded" placeholder="Contact" name="contact" value={formData.contact} onChange={handleChange} />
          <input id="imageInput" className="border p-2 rounded" type="file" name="image" onChange={handleChange} accept="image/*" />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="mt-4 bg-blue-600 text-white px-4 py-2 rounded w-full disabled:opacity-60"
        >
          {loading ? "Submitting..." : "Submit"}
        </button>
      </form>
    </div>
  );
}
