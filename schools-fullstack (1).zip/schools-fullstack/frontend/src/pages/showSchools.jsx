import { useEffect, useState } from "react";
import axios from "axios";

export default function ShowSchools() {
  const [schools, setSchools] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await axios.get((import.meta.env.VITE_API_URL || "http://localhost:5000") + "/schools");
        setSchools(res.data || []);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <div className="p-6">Loading...</div>;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
      {schools.map((school) => (
        <div key={school.id} className="bg-white shadow rounded-2xl p-4 flex flex-col">
          <div className="w-full h-40 bg-gray-100 flex items-center justify-center overflow-hidden rounded-lg mb-3">
            {school.image ? (
              <img
                src={`${import.meta.env.VITE_API_URL || "http://localhost:5000"}/schoolImages/${school.image}`}
                alt={school.name}
                className="object-cover w-full h-full"
              />
            ) : (
              <span className="text-sm text-gray-500">No Image</span>
            )}
          </div>
          <h3 className="text-lg font-semibold">{school.name}</h3>
          <p className="text-gray-600">{school.address}</p>
          <p className="text-gray-600">{school.city}, {school.state}</p>
        </div>
      ))}
      {!schools.length && <div>No schools found.</div>}
    </div>
  );
}
