# Schools App (React + Node + MySQL)

Full-stack example to add and show schools (with image upload).

## Tech
- Backend: Node.js, Express, MySQL, Multer, dotenv, CORS
- Frontend: React (Vite) + Tailwind, Axios, React Router
- DB: MySQL

## Setup

### 1) Database
Import `backend/schema.sql` into MySQL to create the `schoolDB` and `schools` table.

### 2) Backend
```bash
cd backend
cp .env.example .env   # then edit DB creds
npm install
npm start
```
Server runs on `http://localhost:5000`.

### 3) Frontend
```bash
cd frontend
npm install
npm run dev
```
App runs on `http://localhost:5173`.

You can change API base via `frontend/.env` (`VITE_API_URL`).

## Deploy
- Frontend: Vercel/Netlify (build: `npm run build`, output: `dist`).
- Backend: Render/Railway/Heroku (start command: `node server.js`). Ensure you add `schoolImages` as a persistent directory if the host supports it, or switch to cloud storage (S3, etc.) for images in production.

## API
- `POST /addSchool` (multipart/form-data) — fields: name, address, city, state, contact, email_id, image (file)
- `GET /schools` — list all schools

